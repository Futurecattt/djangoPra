from django.contrib import admin
from cart import models
# Register your models here.

admin.site.register(models.OrderModel)
admin.site.register(models.DetailModel)