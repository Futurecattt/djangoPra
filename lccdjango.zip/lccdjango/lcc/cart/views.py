from django.shortcuts import render,redirect
from django.http import HttpResponseRedirect
from cart import models
from product.models import Goods 

# Create your views here.

cartlist = list()
customname = ''
customphone = ''
customaddress = ''
customemail = ''
orderTotal = 0
goodsTitle = list()

def cart(request):
    global cartlist
    goodlist = cartlist
    total = 0
    for unit in cartlist:
        total += int(unit[3])
        if total >= 10000:
            grandtotal = total
        else:
            grandtotal = total+200
        if len(goodlist) == 0:
            empty = 1
        else:
            empty = 0
        return render(request,'cart.html',locals())
    

def addtocart(request ,ctype=None ,productid=None):
    global cartlist #將cartlist設為全域變數
    if ctype == 'add':
        product = Goods.objects.filter(id=productid).count()
        #透過商品id 查尋Goods資料表內有無這種商品
        if product > 0: 
            product = Goods.objects.get(id=productid)
            flag=True #預設購物車裡面沒有相同東西 #7:55
            for unit in cartlist:
                #有此商品，改變數量和總價
                if product.name == unit[0]: #unit[0]:商品名稱  #unit[1]:商品價格
                    unit[2] = str(int(unit[2])+1)             #unit[2]:商品數量
                    unit[3] = str(int(unit[3])+product.price) #unit[3]:商品總價
                    flag = False
                    break
                
            #沒有此商品，所以加入購物車
            if flag: #flag為true 所以判斷式成立
                templist = list()
                templist.append(product.name)
                templist.append(str(product.price))
                templist.append('1')
                templist.append(str(product.price))
                cartlist.append(templist)
                
            request.session['cartlist'] = cartlist
            #覆蓋session內的資料
            return redirect('/cart/')
        else:
            return redirect('/product/')
                
                
    elif ctype == 'update': #修改購物車內的商品數量 #8:28
        n = 0
        for unit in cartlist:
            amount = request.POST.get('gty'+str(n),'1')
            if len(amount) == 0:
                amount = '1'
            if int(amount) <= 0:
                amount = '1'
            unit[2] = amount
            unit[3] = str(int(unit[1]) * int(amount))
            n += 1
        request.session['cartlist'] = cartlist
        return redirect('/cart/')
    
    
    
    
    elif ctype == 'delete':
        pass
    elif ctype == 'empty':
        pass
    




def cartorder(request):
    pass

def cartok(request):
    pass

def cartordercheck(request):
    pass

def myorder(request):
    pass

def reportBank(request):
    pass