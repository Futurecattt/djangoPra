from django.shortcuts import render

import hashlib

from .models import customer

from django.http import HttpResponseRedirect,HttpResponse

# Create your views here.
def login(request):
    
    msg = ""
    if "email" in request.POST:
        email = request.POST['email']
        pwd = request.POST['password']
        pwd = hashlib.sha3_256(pwd.encode('utf-8')).hexdigest()
        obj = customer.objects.filter(email=email,password=pwd).count()
        if obj > 0:
                            #括號內可以自訂
            request.session['cusEmail'] = email
            request.session['isAlive'] = True
            request.session['lcc'] = 'good'
            
            #Redirect 導向
            response = HttpResponseRedirect('/')#將網站重新導向至指定目錄，以這邊來說是跟目錄
            response.set_cookie('UEmail',email,max_age=1200)#cookies 存活時間
            return response
        else:
            msg = "帳號或密碼錯誤"
            return render(request,'login.html',locals())
    else:
        return render(request,'login.html',locals())
    
    

def logout(request):
    #刪除指定的 變數名稱
    del request.session['cusEmail']
    del request.session['isAlive']
    del request.session['lcc']
    
    #request.session.clear() #全刪除
    
    #刪除cookie
    response = HttpResponseRedirect('/')
    response.delete_cookie('UEmail')
    return response
    
    
    
def register(request):#註冊
    msg = ""#用以告訴前台是否註冊成功
    if "uEmail" in request.POST:
        uName = request.POST['uName']
        uEmail = request.POST['uEmail']
        upwd = request.POST['uPassword']
        usex = request.POST['sex']
        ubirthday = request.POST['birthday']
        umobile = request.POST['mobile']
        uaddress = request.POST['address']
        
        #加密
        upwd = hashlib.sha3_256(upwd.encode('utf-8')).hexdigest()
        
        obj=customer.objects.filter(email=uEmail).count()
        
        if obj == 0:
            customer.objects.create(name=uName,sex=usex,birthday=ubirthday,email=uEmail,mobile=umobile,address=uaddress,password=upwd)
            msg = "註冊成功"
        else:
            msg = "這個信箱已被使用"
    return render(request,'register.html',locals())   
        

        
def changepassword(request):
    
    if 'cusEmail' in request.session and 'lcc' in request.session:
        msg = ''
        if 'oldPwd' in request.POST:
            oldPwd = request.POST['oldPwd']
            newPwd = request.POST['newPwd']
            oldPwd = hashlib.sha256(oldPwd.encode('utf-8')).hexdigest()
            newPwd = hashlib.sha256(newPwd.encode('utf-8')).hexdigest()
            email = request.session['cusEmail']
            obj = customer.objects.filter(email=email,password=oldPwd).count()
            if obj > 0:
                user = customer.objects.get(email=email)
                user.password = newPwd
                msg = '密碼變更成功'
            else:
                msg = '舊密碼輸入錯誤，請重新輸入'
        return render(request,'updatepassword.html',locals())
    else:
        return HttpResponseRedirect('/login')
    
    
def updatePensonal(request):
    pass