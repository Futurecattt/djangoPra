from django.shortcuts import render
from .models import Goods
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger

# Create your views here.

def product(request):
    
    q=''
    sp=''
    ep=''
    if 'q' in request.GET:
        q = request.GET['q']
        sp = request.GET['startp']
        ep = request.GET['endp']
        
        if len(q) > 0 and len(sp) == 0 and len(ep) == 0: #以關鍵字搜尋
            data = Goods.objects.filter(name__icontains=q).order_by('-price')
                                        #用關鍵字做搜尋 #icontains 前面的 i 表示輸入的英文不分大小寫
        elif len(q) == 0 and len(sp) > 0 and len(ep) > 0: #以價格為範圍做搜尋
            data = Goods.objects.filter(price__gte=sp,price__lte=ep).order_by('price')  
                          
        elif len(q) > 0 and len(sp) > 0 and len(ep) > 0: #以關鍵字和價格搜尋
            data = Goods.objects.filter(name__icontains=q,price__gte=sp,price__lte=ep).order_by('-price') 
        else:
            data = Goods.objects.all().order_by('-id')                      
    else:
        data = Goods.objects.all().order_by('-id')#由小排到大，所以加上減號
        
        
    paginator = Paginator(data,36)
    page = request.GET.get('page')
    try:
        data = paginator.page(page)
    except PageNotAnInteger:
        data = paginator.page(1)
    except EmptyPage:
        data = paginator.page(paginator.num_pages)
    
    return render(request,'product.html',locals())