from django.db import models

# Create your models here.

class myNews(models.Model):
    title = models.CharField(max_length=50)
    content = models.TextField()
    photo_url = models.CharField(max_length=200)
    c_date = models.DateTimeField(auto_now_add = True)
    
    #django會自動新增主鍵(primary_key)
    #如果是在後台新增資料表，django會自動加上時間
    
    
    class Meta:
        db_table = 'news'
    #建立資料表名稱