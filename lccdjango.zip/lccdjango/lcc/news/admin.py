from django.contrib import admin

# Register your models here.

#註冊到後台

from .models import myNews
admin.site.register(myNews)