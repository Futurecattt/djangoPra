from django.shortcuts import render
from .models import Message

# Create your views here.

def contact(request):
    if 'username' in request.POST: #contact.html>19行>name="username"
        uname = request.POST['username']
        umail = request.POST['email']
        usub = request.POST['subject']
        ucontent = request.POST['content']
        
        #將收到的資料新增至資料庫中的資料表中
        obj = Message.objects.create(name=uname,email=umail,subject=usub,content=ucontent)
                                   #欄位名稱=變數名稱
        obj.save()
        
        #標準的sql語法
        #insert into contact(name,email,subject,content) values('Bill','bill@gamil.com','學python','去哪裡學')
        
        
        
    return render(request,'contact.html')