# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 18:56:29 2023

@author: USER
"""

import requests
from bs4 import BeautifulSoup
from datetime import datetime 
import db

url = "https://news.tvbs.com.tw/realtime"

data = requests.get(url).text

soup = BeautifulSoup(data,'html.parser')
newslist = soup.find('div',class_='news_list')
allnews = newslist.find('div',class_='list')
news = allnews.find_all('li')


for item in news:
    adata = item.find('a')
    if not (adata == None):
        link = 'https://news.tvbs.com.tw' + adata.get('href')
        img = adata.find('img').get('data-original')
        title = adata.find('h2').text
        
        today = datetime.today()
        today = today.strftime('%Y-%m-%d')
        
        sql = "select * from news where title='{}'".format(title)
        db.cur.execute(sql)
        res = db.cur.fetchone()
        if res == None:
            sql = "insert into news(title,content,photo_url,c_date) values('{}','{}','{}','{}')".format(title,title,img,today)
            db.cur.execute(sql)
            db.conn.commit()
        
        
        
        
        #content = requests.get(link).text
        #sp = BeautifulSoup(content,'html.parser')
        #newsinfo = sp.find(id='news_detail_div')
        #info = newsinfo.text
        #info = info.replace('\n','')
        
        #print(title) 
        #print(today)
        #print(img)
        #print(link)
        
        #print(info)
        #break
db.conn.close()      
