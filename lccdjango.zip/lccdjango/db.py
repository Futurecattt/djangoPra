# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 20:12:55 2023

@author: USER
"""

import MySQLdb

conn = MySQLdb.connect(host='localhost',port=3306,user='root',passwd='123456789',db='mylcc')
cur = conn.cursor()